                </section>
            </section>
            <footer>
                <p>&copy; 2024 - Universitas Pelita Bangsa</p>
            </footer>
        </div>
    </body>
</html>